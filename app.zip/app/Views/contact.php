<?php 
$hlm = "Contact";
include 'layout/header.php';
include 'layout/breadcrumb.php';
?>

<div class="card">
  <div class="card-body">
    <h5 class="card-title">Contact</h5>
    <p>ini halaman Contact</p>
  </div>
</div>

<?php include 'layout/footer.php'; ?>
